CREATE
    DEFINER = root@`%` PROCEDURE proc_generate_t_month_company_emp(IN companycode varchar(50), IN bizyear varchar(5))
    COMMENT '生产分公司下员工的绩效详情数据'
BEGIN
    # 遍历公司编码声明的变量
    DECLARE _companycode varchar(50);
    DECLARE _query_month smallint UNSIGNED DEFAULT 12;
    DECLARE _query_month2 smallint UNSIGNED DEFAULT 12;
    DECLARE _store_month smallint UNSIGNED DEFAULT 12;
    DECLARE _current_year mediumint UNSIGNED DEFAULT year(CURRENT_DATE); # 系统当前年份
    DECLARE _biz_year_month varchar(15);

    ## 定义查询变量
    DECLARE _cur CURSOR FOR SELECT code
                            FROM company
                            WHERE enabled = '1'
                              AND is_deleted = 0
                              AND code IN ('129000000',
                                           '105000000',
                                           '118000000',
                                           '109000000',
                                           '107000000',
                                           '125000000',
                                           '121000000',
                                           '104000000',
                                           '106000000',
                                           '111000000',
                                           '101000000',
                                           '110000000',
                                           '120000000',
                                           '108000000',
                                           '124000000',
                                           '123000000',
                                           '114000000',
                                           '122000000',
                                           '113000000',
                                           '112000000',
                                           '116000000',
                                           '102000000',
                                           '117000000',
                                           '119000000',
                                           '127000000');
    ## 循环赋初始值
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _companycode = NULL;

    # 设置查询的哪个年份
    IF (ifnull(bizyear, 1) <> 1 AND bizyear <> '')
    THEN
        IF (length(bizyear) <> 4)
        THEN
            SET bizyear = _current_year;
        ELSEIF (bizyear > _current_year)
        THEN
            SET bizyear = _current_year;
        END IF;
    ELSE
        SET bizyear = _current_year;
    END IF;

    # 处于当前年的话只查询到前一个月份
    IF (bizyear = _current_year)
    THEN
        SELECT (month(CURRENT_DATE) - 1) INTO _query_month;
    END IF;

    # 年份转成数值类型
    SELECT cast(bizyear AS UNSIGNED) INTO bizyear;

    # 如果不存在就创建每月分公司员工信息表(主键自增)
    CREATE TABLE IF NOT EXISTS t_month_company_emp (
        id           bigint               NOT NULL AUTO_INCREMENT,
        biz_year     smallint(5) UNSIGNED NULL COMMENT '年份',
        biz_month    tinyint UNSIGNED     NULL COMMENT '月份',
        biz_day      tinyint UNSIGNED     NULL COMMENT '天数（冗余字段）',
        company_id   bigint               NULL,
        company_code varchar(50)          NULL,
        company_name varchar(150)         NULL,
        emp_type     tinyint UNSIGNED     NULL COMMENT '0-设计师，1-营销员[整装事业部下]',
        emp_id       bigint               NULL,
        work_number  varchar(20)          NULL COMMENT '员工工号',
        emp_name     varchar(50)          NULL,
        PRIMARY KEY (id)
    )
        ENGINE = InnoDB
        DEFAULT CHARSET = utf8mb4;
    IF NOT EXISTS(SELECT *
                  FROM information_schema.statistics
                  WHERE table_name = 't_month_company_emp'
                    AND index_name = 't_month_company_emp_company_code_index')
    THEN
        ALTER TABLE t_month_company_emp
            ADD INDEX t_month_company_emp_company_code_index (company_code);
    END IF;


    IF (ifnull(companycode, 1) <> 1 AND companycode <> '')
    THEN
        ## 循环月份
        REPEAT
            -- 循环开始
            ############################################ 循环体 #######################################
            SELECT CONCAT_WS('-', bizyear, lpad(_query_month, 2, 0)) INTO _biz_year_month;

            # 重复调用，先删除原来的值，再插入数据
            IF exists(SELECT id
                      FROM t_month_company_emp
                      WHERE company_code = companycode AND biz_year = bizyear AND biz_month = _query_month)
            THEN
                DELETE
                FROM t_month_company_emp
                WHERE company_code = companycode AND biz_year = bizyear AND biz_month = _query_month;
            END IF;

            SELECT concat('开始向t_month_company_emp表，保存数据');

            # 保存数据
            INSERT INTO t_day_company_emp(work_number, company_code, emp_type, biz_year, biz_month, emp_id, emp_name,
                                          company_id, company_name)
                (
                    SELECT *
                    FROM (
                             SELECT emp.work_number,
                                    c.code,
                                    1,
                                    bizyear,
                                    _query_month,
                                    emp.id   emp_id,
                                    emp.name emp_name,
                                    c.id     company_id,
                                    c.name   company_name
                             FROM employee emp
                                      INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                      INNER JOIN department d ON d.id = dp.department_id
                                      INNER JOIN company c ON c.id = d.company_id
                             WHERE c.code = companycode
                               AND status = '1'
                               AND dp.name = '设计师'
                               AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     1,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '0'
                                AND dp.name = '设计师'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '1'
                                AND dp.name = '传媒客户经理'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '0'
                                AND dp.name = '传媒客户经理'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '1'
                                AND dp.name = '网络客户经理'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '0'
                                AND dp.name = '网络客户经理'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '1'
                                AND dp.name = '家居顾问'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                             UNION ALL
                             (SELECT emp.work_number,
                                     c.code,
                                     0,
                                     bizyear,
                                     _query_month,
                                     emp.id   emp_id,
                                     emp.name emp_name,
                                     c.id     company_id,
                                     c.name   company_name
                              FROM employee emp
                                       INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                       INNER JOIN department d ON d.id = dp.department_id
                                       INNER JOIN company c ON c.id = d.company_id
                              WHERE c.code = companycode
                                AND status = '0'
                                AND dp.name = '家居顾问'
                                AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                         ) tmp
                );
            SET _query_month = _query_month - 1;
            -- 条件控制
            ############################################ 循环体 #######################################
        UNTIL _query_month < 1 END REPEAT; -- 每年的月数循环结束
    ELSE
        ## 打开游标
        OPEN _cur;
        ## 赋值
        FETCH _cur INTO _companycode;
        ###循环判断
        WHILE (_companycode IS NOT NULL)
            DO
                SET @companycode = _companycode;
                # 每个分公司重置一下月份数数据
                SET _query_month = _store_month;
                ## 循环
                REPEAT
                    -- 循环开始
                    ############################################ 循环体 #######################################
                    SELECT CONCAT_WS('-', bizyear, lpad(_query_month, 2, 0)) INTO _biz_year_month;

                    # 重复调用，先删除原来的值，在插入数据
                    IF exists(SELECT id FROM t_month_company_emp WHERE company_code = @companycode
                                                                   AND biz_year = bizyear
                                                                   AND biz_month = _query_month)
                    THEN
                        DELETE
                        FROM t_month_company_emp
                        WHERE company_code = @companycode AND biz_year = bizyear AND biz_month = _query_month;
                    END IF;

                    # 保存数据
                    INSERT INTO t_month_company_emp(work_number, company_code, emp_type, biz_year, biz_month, emp_id,
                                                    emp_name, company_id, company_name)
                        (
                            SELECT *
                            FROM (
                                     SELECT emp.work_number,
                                            c.code   company_code,
                                            0,
                                            bizyear,
                                            _query_month,
                                            emp.id   emp_id,
                                            emp.name emp_name,
                                            c.id     company_id,
                                            c.name   company_name
                                     FROM employee emp
                                              INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                              INNER JOIN department d ON d.id = dp.department_id
                                              INNER JOIN company c ON c.id = d.company_id
                                              INNER JOIN position p ON p.id = dp.position_id
                                     WHERE c.code = companycode
                                       AND status = '1'
                                       AND p.name = '设计师'
                                       AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                     UNION ALL
                                     (SELECT emp.work_number work_number,
                                             c.code          company_code,
                                             0,
                                             bizyear,
                                             _query_month,
                                             emp.id          emp_id,
                                             emp.name        emp_name,
                                             c.id            company_id,
                                             c.name          company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '0'
                                        AND p.name = '设计师'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                        AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '1'
                                        AND p.name = '传媒客户经理'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '0'
                                        AND p.name = '传媒客户经理'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                        AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '1'
                                        AND p.name = '网络客户经理'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '0'
                                        AND p.name = '网络客户经理'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                        AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '1'
                                        AND p.name = '家居顾问'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month)
                                     UNION ALL
                                     (SELECT emp.work_number,
                                             c.code   company_code,
                                             1,
                                             bizyear,
                                             _query_month,
                                             emp.id   emp_id,
                                             emp.name emp_name,
                                             c.id     company_id,
                                             c.name   company_name
                                      FROM employee emp
                                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                                               INNER JOIN department d ON d.id = dp.department_id
                                               INNER JOIN company c ON c.id = d.company_id
                                               INNER JOIN position p ON p.id = dp.position_id
                                      WHERE c.code = companycode
                                        AND status = '0'
                                        AND p.name = '家居顾问'
                                        AND date_format(emp.start_date, '%Y-%m') <= _biz_year_month
                                        AND date_format(emp.resigned_date, '%Y-%m') >= _biz_year_month)
                                 ) tmp
                        );
                    SET _query_month = _query_month - 1;
                    -- 条件控制
                    ############################################ 循环体 #######################################
                UNTIL _query_month = 0 END REPEAT;
                -- 循环结束
                ## 赋值下一个游标
                FETCH _cur INTO _companycode;
            END WHILE;
        ## 关闭游标
        CLOSE _cur;
    END IF;

END;


CREATE
    DEFINER = root@`%` FUNCTION core_part_substring_zero(O_PART_NO varchar(256)) RETURNS varchar(128)
    COMMENT '截取字符串前面多余的0'
BEGIN
    /*
        1、针对字符串前面出现多余的0进行拦截
    */
    DECLARE BOO_SIGN_V tinyint(1);
    DECLARE TEMP_PART_NO VARCHAR(256);
    DECLARE NEW_PART_NO VARCHAR(256);
    /*
		1、MYSQL保存BOOLEAN值时用1代表TRUE,0代表FALSE,boolean在MySQL里的类型为tinyint(1),
		2、MySQL里有四个常量：true,false,TRUE,FALSE,它们分别代表1,0,1,0
		3、SELECT core_part_substring_zero('000A00B00C00');
	*/
    SET TEMP_PART_NO = O_PART_NO;
    SET NEW_PART_NO = '';
    /* 判断字符串第一个字符是否是'0'(TRUE-1,FALSE-0) */
    SELECT INSTR(O_PART_NO, '0') INTO BOO_SIGN_V;
    /* 如果前面没有多余的'0',那么直接返回 */
    IF BOO_SIGN_V = 0
    THEN
        SET NEW_PART_NO = O_PART_NO;
    END IF;
    /* 递归迭代移除 */
    WHILE INSTR(TEMP_PART_NO, '0') = 1
        DO
            SELECT SUBSTR(TEMP_PART_NO, 2, LENGTH(TEMP_PART_NO)) INTO TEMP_PART_NO;
        END WHILE;
    /* 重置最后的结果值 */
    SET NEW_PART_NO = TEMP_PART_NO;

    RETURN NEW_PART_NO;
END;


CREATE
    DEFINER = root@`%` PROCEDURE proc_generate_current_month_valid_emp() COMMENT '自动生产本月有效员工数据'
BEGIN

    # 检查是否存在表(主键自增)
    CREATE TABLE IF NOT EXISTS t_month_company_emp (
        id           bigint               NOT NULL AUTO_INCREMENT,
        biz_year     smallint(5) UNSIGNED NULL COMMENT '年份',
        biz_month    tinyint UNSIGNED     NULL COMMENT '月份',
        biz_day      tinyint UNSIGNED     NULL COMMENT '天数（冗余字段）',
        company_id   bigint               NULL,
        company_code varchar(50)          NULL,
        company_name varchar(150)         NULL,
        emp_type     tinyint UNSIGNED     NULL COMMENT '0-设计师，1-营销员[整装事业部下]',
        emp_id       bigint               NULL,
        work_number  varchar(20)          NULL COMMENT '员工工号',
        emp_name     varchar(50)          NULL,
        PRIMARY KEY (id)
    )
        ENGINE = InnoDB
        DEFAULT CHARSET = utf8mb4;
    IF NOT EXISTS(SELECT *
                  FROM information_schema.statistics
                  WHERE table_name = 't_month_company_emp'
                    AND index_name = 't_month_company_emp_company_code_index')
    THEN
        ALTER TABLE t_month_company_emp
            ADD INDEX t_month_company_emp_company_code_index (company_code);
    END IF;
    # 插入每月有效员工数据
    # 保存数据
    INSERT INTO t_month_company_emp(work_number, company_code, emp_type, biz_year, biz_month, emp_id, emp_name,
                                    company_id, company_name)
        (
            SELECT *
            FROM (
                     SELECT emp.work_number,
                            c.code,
                            1,
                            YEAR(CURDATE())  biz_year,
                            month(CURDATE()) biz_month,
                            emp.id           emp_id,
                            emp.name         emp_name,
                            c.id             company_id,
                            c.name           company_name
                     FROM employee emp
                              INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                              INNER JOIN department d ON d.id = dp.department_id
                              INNER JOIN company c ON c.id = d.company_id
                     WHERE status = '1'
                       AND dp.name = '设计师'
                       AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m')
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             1,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '0'
                        AND dp.name = '设计师'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m')
                        AND date_format(emp.resigned_date, '%Y-%m') >= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '1'
                        AND dp.name = '传媒客户经理'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '0'
                        AND dp.name = '传媒客户经理'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m')
                        AND date_format(emp.resigned_date, '%Y-%m') >= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '1'
                        AND dp.name = '网络客户经理'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '0'
                        AND dp.name = '网络客户经理'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m')
                        AND date_format(emp.resigned_date, '%Y-%m') >= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '1'
                        AND dp.name = '家居顾问'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m'))
                     UNION ALL
                     (SELECT emp.work_number,
                             c.code,
                             0,
                             YEAR(CURDATE())  biz_year,
                             month(CURDATE()) biz_month,
                             emp.id           emp_id,
                             emp.name         emp_name,
                             c.id             company_id,
                             c.name           company_name
                      FROM employee emp
                               INNER JOIN department_position dp ON emp.primary_dept_pos_id = dp.id
                               INNER JOIN department d ON d.id = dp.department_id
                               INNER JOIN company c ON c.id = d.company_id
                      WHERE status = '0'
                        AND dp.name = '家居顾问'
                        AND date_format(emp.start_date, '%Y-%m') <= date_format(CURDATE(), '%Y-%m')
                        AND date_format(emp.resigned_date, '%Y-%m') >= date_format(CURDATE(), '%Y-%m'))
                 ) tmp
        );
END;


CREATE
    DEFINER = root@`%` PROCEDURE proc_loop_generate_month_valid_emp_data(IN startyear varchar(5))
    COMMENT '执行总公司下所有分公司从2011起，每年每月有效员工数据'
BEGIN
    # 声明参与循环的年份变量
    DECLARE _startyear smallint UNSIGNED DEFAULT 2018; # 2011，公司开创元年,暂时定义为2018年
    DECLARE _endyear smallint UNSIGNED DEFAULT year(CURRENT_DATE);
    DECLARE _loopTemp smallint UNSIGNED;

    ## 创建游标1
    DECLARE _companycode varchar(50);
    DECLARE _curcompany CURSOR FOR SELECT code
                                   FROM company
                                   WHERE enabled = '1'
                                     AND is_deleted = 0
                                     AND code IN ('129000000',
                                                  '105000000',
                                                  '118000000',
                                                  '109000000',
                                                  '107000000',
                                                  '125000000',
                                                  '121000000',
                                                  '104000000',
                                                  '106000000',
                                                  '111000000',
                                                  '101000000',
                                                  '110000000',
                                                  '120000000',
                                                  '108000000',
                                                  '124000000',
                                                  '123000000',
                                                  '114000000',
                                                  '122000000',
                                                  '113000000',
                                                  '112000000',
                                                  '116000000',
                                                  '102000000',
                                                  '117000000',
                                                  '119000000',
                                                  '127000000');
    ## 循环赋初始值
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _companycode = NULL;

    ## 外界设置开始执行年份
    IF (ifnull(startyear, 1) <> 1 AND startyear <> '' AND length(startyear) = 4)
    THEN
        IF (startyear > _endyear)
        THEN
            SET _startyear = _endyear;
        END IF;
    END IF;

    # 循环的起始年份
    SET _loopTemp = _startyear;

    ## 打开游标
    OPEN _curcompany;
    ## 赋值
    FETCH _curcompany INTO _companycode;
    ###循环判断
    WHILE (_companycode IS NOT NULL)
        DO
        ################## 循环体 ###############
        # 重置开始年份
            SET _loopTemp = _startyear;
            REPEAT
                -- 循环开始
                SELECT concat('当前循环的年份：', _loopTemp);
                SELECT concat('执行的最后年份：', _endyear);
                CALL proc_generate_t_month_company_emp(_companycode, _loopTemp);
                SET _loopTemp = _loopTemp + 1;
                -- 条件控制
                ############################################ 循环体 #######################################
            UNTIL _loopTemp > _endyear END REPEAT;
            ################## END  ################
            ## 赋值下一个游标
            FETCH _curcompany INTO _companycode; -- 循环条件
        END WHILE;
    # 关闭游标
    CLOSE _curcompany;

END;

